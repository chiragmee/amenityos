NOOKLY — FINAL LOGO ASSETS
=============================

Brand colours
Graphite  #22262B
Signage White  #F2F3F1
Amber  #E8A33D

The SVGs are the master assets. PNGs are rendered from the same SVG artwork.
All light-background logo/mark PNGs are transparent. Dark variants include the graphite ground.
The wordmark is sentence case: "nookly".

Directions
1. Door Nook — open doorway + warm booking moment
2. Corner Room — room corner + reserved block
3. N Window — rounded n-shape + opening
4. Pocket — contained nook + entry
5. Floor Fold — floor-plan/folded-space cue
6. Way In — path turning into a doorway

Recommended primary: 01_door_nook
Recommended secondary: 03_n_window
